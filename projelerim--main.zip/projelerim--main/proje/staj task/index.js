// Aktif olan navigasyon öğesinin sırasını temsil eden değişken
var activeNavOrder = "0";

// Navigasyon öğelerini ve içeriklerini al
var navItems = document.getElementsByClassName("nav-item");
var navContents = document.getElementsByClassName("nav-content");
var navContentArea = document.getElementById("nav-content-area");
var activeNavContent;

// Aktif navigasyon öğesini hesaplayan fonksiyon
var computeActiveNav = function () {
  for (var i = 0; i < navItems.length; i++) {
    if (i === Number(activeNavOrder)) {
      // Aktif öğeyi belirle ve gerekli stil sınıflarını ekle
      navContents[i].classList.add("nav-content--active");
      activeNavContent = navContents[i];
      navContentArea.style.height = window.getComputedStyle(
        navContents[i]
      ).height;
      navItems[i].classList.add("nav-item--active");
    } else {
      // Diğer öğelerden stil sınıflarını kaldır
      navContents[i].classList.remove("nav-content--active");
      navItems[i].classList.remove("nav-item--active");
    }
  }
};

// Sayfa yüklendiğinde aktif navigasyon öğesini hesapla
computeActiveNav();

// Navigasyon öğelerine tıklama olayını dinle
var handleNavClickEvent = function () {
  // Tıklanan öğenin sırasını al ve aktif navigasyonu güncelle
  activeNavOrder = this.getAttribute("data-nav-order");
  computeActiveNav();
};

// Her bir navigasyon öğesine tıklama olayını ekleyerek dinle
for (var i = 0; i < navItems.length; i++) {
  navItems[i].addEventListener("click", handleNavClickEvent, false);
}

// Pencerenin boyutu değiştiğinde aktif içeriğin yüksekliğini güncelle
window.addEventListener("resize", (event) => {
  if (activeNavContent) {
    navContentArea.style.height =
      window.getComputedStyle(activeNavContent).height;
  }
});